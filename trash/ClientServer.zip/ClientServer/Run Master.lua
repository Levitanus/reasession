------------------------------------------------------------------------------------------
local CS_Section="__CS__"
local msg = function(M) reaper.ShowConsoleMsg(tostring(M).."\n") end
------------------------------------------------------------------------------------------
function get_script_path()
  local info = debug.getinfo(1,'S')
  local script_path = info.source:match[[^@?(.*[\/])[^\/]-$]]
  return script_path
end

local sep = package.config:sub(1, 1) -- получаем правильный для ОС-и сепаратор
local script_path = get_script_path()

package.path = package.path .. ";" .. script_path .."?.lua"
------------------------------------------------------------------------------------------

local scriptName = "ClientServer_n2.eel" -- имя TCP Client/Server EEL
local ClientServer = script_path..sep..scriptName -- имя скрипта с путём
reaper.SetExtState(CS_Section, "OnOff", "1", false) -- ставим флаг для запуска TCP EEL

----------- Функция сканирует reaper-kb.ini и выясняет - зарегестрирован ли скрипт -------
local function findCommandID(name)
  local commandID
  local lines = {}
  local fn = reaper.GetResourcePath()..sep.."reaper-kb.ini"
  for line in io.lines(fn) do
    lines[#lines + 1] = line
  end

  for i,v in pairs(lines) do
    if ( v:find(name, 1, true) ) then
      local startidx = v:find("RS", 1, true)
      local endidx = v:find(" ", startidx, true)
      commandID = (v:sub(startidx,endidx-1))
    end
  end

  if commandID then
    return "_"..commandID
  else
    local commandID = reaper.AddRemoveReaScript(true, 0, ClientServer, true) -- если ещё не зарегистрирован - регистрируем и узнаём ID
    local commandID = reaper.ReverseNamedCommandLookup(commandID)
    return "_"..commandID
  end
end
------------------------------------------------------------------------------------------
local cmdID = findCommandID(scriptName) -- получаем commandID ClientServer
reaper.Main_OnCommand(reaper.NamedCommandLookup(cmdID), 0) -- запускаем в Action - наш Скрипт ClientServer
------------------------------------------------------------------------------------------

function RunServer()
  reaper.SetExtState(CS_Section, "addr", "", false)
end

function Receive()
  if reaper.HasExtState(CS_Section,"r_type") then
    local btype=reaper.GetExtState(CS_Section, "r_type")
    local name=reaper.GetExtState(CS_Section, "r_name")
    local val=reaper.GetExtState(CS_Section, "r_val")
    msg(string.format("type:%d name:%s val:%s", btype, name, val))
    reaper.DeleteExtState(CS_Section,"r_type",true)
  end
  reaper.defer(Receive)
end


-- Set ToolBar Button ON --
function SetButtonON()
  local _, _, sec, cmd, _, _, _ = reaper.get_action_context()
  state = reaper.GetToggleCommandStateEx( sec, cmd )
  reaper.SetToggleCommandState( sec, cmd, 1 ) -- Set ON
  reaper.RefreshToolbar2( sec, cmd )
end
-- Set ToolBar Button OFF ---
function SetButtonOFF()
  reaper.SetExtState(CS_Section, "OnOff", "0", false) -- ставим флаг для остановки TCP EEL
  local _, _, sec, cmd, _, _, _ = reaper.get_action_context()
  state = reaper.GetToggleCommandStateEx( sec, cmd )
  reaper.SetToggleCommandState( sec, cmd, 0 ) -- Set OFF
  reaper.RefreshToolbar2( sec, cmd )
end

RunServer()
Receive()

SetButtonON()
reaper.atexit(SetButtonOFF)
