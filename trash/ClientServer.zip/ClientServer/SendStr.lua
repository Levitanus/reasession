------------------------------------------------------------------------------------------
local CS_Section="__CS__";
local msg = function(M) reaper.ShowConsoleMsg(tostring(M).."\n") end
------------------------------------------------------------------------------------------

function IsCSbusy()
  if reaper.HasExtState(CS_Section,"s_type") then return true end
  return false
end

function SendStr(name,val)
  reaper.SetExtState(CS_Section,"s_name",name,false)
  reaper.SetExtState(CS_Section,"s_val",val,false)
  reaper.SetExtState(CS_Section,"s_type","1",false)
end

if IsCSbusy() then
  msg("Master TCP Busy========\n")
else
  SendStr("My_name","My_value");
end
